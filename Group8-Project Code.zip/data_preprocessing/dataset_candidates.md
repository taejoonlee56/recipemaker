## Taejoon Lee

1. RecipeNLG dataset [Kaggle](https://www.kaggle.com/datasets/saldenisov/recipenlg/data)
2. Recipe Ingredients Dataset [Kaggle](https://www.kaggle.com/datasets/kaggle/recipe-ingredients-dataset/data?select=train.json)
3. Indonesian Food Recipes [Kaggle](https://www.kaggle.com/datasets/canggih/indonesian-food-recipes)
4. Recipe Dataset (over 2M) Food [Kaggle](https://www.kaggle.com/datasets/wilmerarltstrmberg/recipe-dataset-over-2m)
5. Healthy Indian Recipes [Kaggle](https://www.kaggle.com/datasets/bhavyadhingra00020/healthy-indian-recipes)
6. Indian Food Recipes Dataset (Cleaned Version) [Kaggle](https://www.kaggle.com/datasets/sooryaprakash12/cleaned-indian-recipes-dataset)
7. Recipes by Ingredients [Kaggle](https://www.kaggle.com/datasets/alincijov/cooking-ingredients)
8. 7000+ International Cuisine [Kaggle](https://www.kaggle.com/datasets/rumitpathare/indian-recipes)